---
name: "💡 Feature Request"
about: 'For ideas or feature requests, make a PR or talk to the core members on Slack'
---

If you would like to propose new features, please make a pull request. Alternatively, you may message the core team on the OctoberCMS Slack.